### R code from vignette source 'statTarget.Rnw'

###################################################
### code chunk number 1: sessInfo
###################################################
toLatex(sessionInfo())


###################################################
### code chunk number 2: resetOptions
###################################################
options(prompt="> ", continue="+ ")


